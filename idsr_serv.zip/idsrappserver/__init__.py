#!/usr/bin/env python

 from IdsrAppServer import IdsrAppServer

#idsr = idsrappserver.IdsrAppServer()
#idsr.startEpidemics()
